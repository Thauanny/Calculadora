package com.example.projeto01_calculadora;

import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;

public class FragmentPageAdapter (fragmentManager:FragmentManager, lifeCycle :Lifecycle){
}
